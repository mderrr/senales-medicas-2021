import final_shared_santih as shared

@shared.presentPoint
def main():
    print("El algoritmo usado por alcides es una buena opcion cunado se trata de hallar picos, yo personalmente hubiese usadado una envoltura de RMS y encontrado los picos asi pero el algoritmo de apb peaks es mas que adecuado para la tarea, sin embargo alcides tiene varias cambios a este algoritmo base que son extrraños y ademas del desorden del codigo estos no son explicados por medio de comnetarios u otros metodos, lo cual hace el codigo y por ende la modificacion del codigo para mejorarlo dificil.")

if __name__ == "__main__":
    main()