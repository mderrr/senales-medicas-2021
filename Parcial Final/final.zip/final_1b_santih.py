import numpy
from matplotlib import pyplot
import final_shared_santih as shared

@shared.presentPoint
def main():
    print("Si, hay una diferencia notable entre las dos señales por lo cual yo considero que la presencia de latidos ectopicos tiene un efecto importante, si el paciente tuviera mas latidos ectopicos el tiempo promedio entre los picos aumentaria y asi tambien lo haria la frecuencia cardiaca lo cual nos puede dar informacion confusa hacerca de la frecuencia cardia normal del paciente.")

if __name__ == "__main__":
    main()