import final_shared_santih as shared

@shared.presentPoint
def main():
    print("Cambios para el procesamiento de la señal:")
    print("Linea 23: Cambie el multiplicador de la desviacion estandar a 10")
    print("Linea 24: Cambie el multiplicador de la desviacion estandar a 10")
    print("Linea 27: Cambie el orden del filtro de 5 a 3")

if __name__ == "__main__":
    main()